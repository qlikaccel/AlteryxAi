"""Utility functions and helpers"""

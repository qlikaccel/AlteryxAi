"""Pydantic request/response schemas"""

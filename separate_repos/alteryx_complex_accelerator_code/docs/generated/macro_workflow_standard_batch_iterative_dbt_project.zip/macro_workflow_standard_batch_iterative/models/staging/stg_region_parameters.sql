{{ config(materialized='view') }}

-- Source extracted from Alteryx input: region_parameters.csv
-- Replace source schema/table mapping after data is landed in BigQuery/Snowflake/warehouse.
select
    *
from {{ source('alteryx_raw', 'region_parameters') }}

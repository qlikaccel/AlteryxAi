{{ config(materialized='view') }}

-- Source extracted from Alteryx input: orders_AI.csv
-- Replace source schema/table mapping after data is landed in BigQuery/Snowflake/warehouse.
select
    *
from {{ source('alteryx_raw', 'orders_ai') }}

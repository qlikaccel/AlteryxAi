{{ config(materialized='table') }}

-- dbt-compatible scaffold generated from Alteryx workflow metadata.
-- Review macro, iterative, batch, Python, API, and multi-input semantics before production use.
-- Macro dependency: Standard macros/standard_cleanse.yxmc (status: ready)
-- Macro dependency: Batch macros/batch_region_processor.yxmc (status: ready)
-- Macro dependency: Iterative macros/iterative_hierarchy_expand.yxmc (status: ready)

with base as (
    select * from {{ ref('stg_orders_ai') }}
)

select
    *
from base

# Macro Remediation Notes

Alteryx macros are represented as review notes in this dbt scaffold. Batch and iterative macro behavior should be rewritten as SQL models, dbt macros, or orchestration logic after expected outputs are confirmed.
